/* =====================================================================
   MAHADEV DANA PANI — SCRIPT.JS
   All editable restaurant data lives at the top of this file.
   ===================================================================== */

/* ---------------------------------------------------------------------
   1. RESTAURANT CONFIG — edit this to update core details site-wide
   --------------------------------------------------------------------- */
const restaurant = {
  name: "Mahadev Dana Pani",
  phone: "08865861735",          // used for tel: links (no spaces)
  phoneDisplay: "088658 61735",
  address: "Roadways Bus Stand, Jila Parisad Colony, Muzaffarnagar, Uttar Pradesh 251001",
  rating: "4.4",
  reviews: "714",
  priceRange: "₹1–200",
  cuisine: "North Indian",

  // Set this to a real WhatsApp number (with country code, digits only,
  // e.g. "919876543210") to enable WhatsApp ordering / contact buttons.
  // Leave as "" to have WhatsApp buttons fall back to a phone call.
  whatsapp: "ADD_WHATSAPP_NUMBER_HERE"
};

/* ---------------------------------------------------------------------
   2. POPULAR DISHES — "Popular From Our Kitchen" section
   Prices are placeholders where not supplied — edit freely.
   --------------------------------------------------------------------- */
const popularDishes = [
  {
    name: "Special Thali",
    desc: "A complete plate with dal, sabzi, roti, rice, salad and raita.",
    price: "Ask for price",
    img: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?q=80&w=800&auto=format&fit=crop"
  },
  {
    name: "Dal Makhani",
    desc: "Slow-cooked black lentils finished with butter and cream.",
    price: "Ask for price",
    img: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?q=80&w=800&auto=format&fit=crop"
  },
  {
    name: "Paneer Dish",
    desc: "Fresh paneer simmered in a rich North Indian gravy.",
    price: "Ask for price",
    img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?q=80&w=800&auto=format&fit=crop"
  },
  {
    name: "Tandoori Roti",
    desc: "Whole-wheat bread, cooked fresh to order in the tandoor.",
    price: "Ask for price",
    img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?q=80&w=800&auto=format&fit=crop"
  },
  {
    name: "Steamed Rice",
    desc: "Light, fluffy rice served with our curries and dal.",
    price: "Ask for price",
    img: "https://images.unsplash.com/photo-1512058564366-18510be2db19?q=80&w=800&auto=format&fit=crop"
  },
  {
    name: "Curd / Raita",
    desc: "Fresh curd, cooling and simple, alongside your meal.",
    price: "Ask for price",
    img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?q=80&w=800&auto=format&fit=crop"
  },
  {
    name: "Chole",
    desc: "Chickpeas simmered in a spiced tomato-onion masala.",
    price: "Ask for price",
    img: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?q=80&w=800&auto=format&fit=crop"
  },
  {
    name: "Masala Chai",
    desc: "Hot spiced tea, the perfect finish to any meal.",
    price: "Ask for price",
    img: "https://images.unsplash.com/photo-1571934811356-5cc061b6821f?q=80&w=800&auto=format&fit=crop"
  }
];

/* ---------------------------------------------------------------------
   3. MENU ITEMS — "Our Menu" section
   category must be one of: main | thali | bread | rice | snacks | beverages
   --------------------------------------------------------------------- */
const menuItems = [
  { name: "Mahadev Special Thali", desc: "Dal, seasonal sabzi, roti, rice, salad, papad and raita.", price: "Ask for price", category: "thali", img: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?q=80&w=800&auto=format&fit=crop" },
  { name: "Simple Veg Thali", desc: "A light everyday thali with dal, sabzi and roti.", price: "Ask for price", category: "thali", img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?q=80&w=800&auto=format&fit=crop" },
  { name: "Dal Makhani", desc: "Black lentils, slow-cooked with butter and cream.", price: "Ask for price", category: "main", img: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?q=80&w=800&auto=format&fit=crop" },
  { name: "Dal Tadka", desc: "Yellow lentils tempered with ghee, cumin and garlic.", price: "Ask for price", category: "main", img: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?q=80&w=800&auto=format&fit=crop" },
  { name: "Paneer Butter Masala", desc: "Paneer cubes in a creamy tomato gravy.", price: "Ask for price", category: "main", img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?q=80&w=800&auto=format&fit=crop" },
  { name: "Mix Veg", desc: "Seasonal vegetables cooked in a light home-style masala.", price: "Ask for price", category: "main", img: "https://images.unsplash.com/photo-1567337710282-00832b415979?q=80&w=800&auto=format&fit=crop" },
  { name: "Chole Masala", desc: "Chickpeas in a spiced tomato-onion gravy.", price: "Ask for price", category: "main", img: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?q=80&w=800&auto=format&fit=crop" },
  { name: "Tandoori Roti", desc: "Whole-wheat bread from the tandoor.", price: "Ask for price", category: "bread", img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?q=80&w=800&auto=format&fit=crop" },
  { name: "Butter Naan", desc: "Soft leavened bread finished with butter.", price: "Ask for price", category: "bread", img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?q=80&w=800&auto=format&fit=crop" },
  { name: "Plain Rice", desc: "Steamed basmati rice.", price: "Ask for price", category: "rice", img: "https://images.unsplash.com/photo-1512058564366-18510be2db19?q=80&w=800&auto=format&fit=crop" },
  { name: "Jeera Rice", desc: "Basmati rice tempered with cumin.", price: "Ask for price", category: "rice", img: "https://images.unsplash.com/photo-1512058564366-18510be2db19?q=80&w=800&auto=format&fit=crop" },
  { name: "Samosa", desc: "Crisp pastry filled with spiced potato.", price: "Ask for price", category: "snacks", img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?q=80&w=800&auto=format&fit=crop" },
  { name: "Fresh Salad", desc: "Onion, cucumber, tomato and lemon.", price: "Ask for price", category: "snacks", img: "https://images.unsplash.com/photo-1567337710282-00832b415979?q=80&w=800&auto=format&fit=crop" },
  { name: "Masala Chai", desc: "Hot spiced tea.", price: "Ask for price", category: "beverages", img: "https://images.unsplash.com/photo-1571934811356-5cc061b6821f?q=80&w=800&auto=format&fit=crop" },
  { name: "Buttermilk (Chaas)", desc: "Chilled spiced buttermilk.", price: "Ask for price", category: "beverages", img: "https://images.unsplash.com/photo-1626200419199-391ae4be7a41?q=80&w=800&auto=format&fit=crop" }
];

/* ---------------------------------------------------------------------
   4. GALLERY IMAGES
   Replace src with assets/images/gallery-1.jpg etc. once you have the
   restaurant's own photography.
   --------------------------------------------------------------------- */
const galleryImages = [
  { src: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?q=80&w=1000&auto=format&fit=crop", alt: "Full North Indian vegetarian thali", caption: "Special Thali" },
  { src: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?q=80&w=1000&auto=format&fit=crop", alt: "Bowl of dal makhani", caption: "Dal Makhani" },
  { src: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?q=80&w=1000&auto=format&fit=crop", alt: "Paneer curry dish", caption: "Paneer Curry" },
  { src: "https://images.unsplash.com/photo-1601050690597-df0568f70950?q=80&w=1000&auto=format&fit=crop", alt: "Freshly made tandoori roti and naan", caption: "Tandoori Bread" },
  { src: "https://images.unsplash.com/photo-1571934811356-5cc061b6821f?q=80&w=1000&auto=format&fit=crop", alt: "Cup of hot masala chai", caption: "Masala Chai" },
  { src: "https://images.unsplash.com/photo-1567337710282-00832b415979?q=80&w=1000&auto=format&fit=crop", alt: "Fresh vegetable salad", caption: "Fresh Salad" },
  { src: "https://images.unsplash.com/photo-1512058564366-18510be2db19?q=80&w=1000&auto=format&fit=crop", alt: "Steamed rice served in a bowl", caption: "Steamed Rice" },
  { src: "https://images.unsplash.com/photo-1626200419199-391ae4be7a41?q=80&w=1000&auto=format&fit=crop", alt: "Glass of chilled buttermilk", caption: "Chaas" },
  { src: "https://images.unsplash.com/photo-1552566626-52f8b828add9?q=80&w=1000&auto=format&fit=crop", alt: "Warm, welcoming restaurant seating area", caption: "Our Dining Space" }
];

/* ---------------------------------------------------------------------
   5. REVIEWS
   --------------------------------------------------------------------- */
const reviews = [
  {
    name: "Neeraj Barty",
    rating: 5,
    text: "Food was awesome, and so was the ambience. Loved every bit of this restaurant and loved the retro vibe."
  },
  {
    name: "Guest Diner",
    rating: 5,
    text: "Love this place... ambience and food are awesome."
  },
  {
    name: "Regular Customer",
    rating: 4,
    text: "Good, honest vegetarian food at a fair price. A reliable stop near the bus stand."
  }
];

/* =====================================================================
   RENDER FUNCTIONS
   ===================================================================== */

function starString(rating){
  return "★".repeat(rating) + "☆".repeat(5 - rating);
}

function renderPopularDishes(){
  const grid = document.getElementById("popularGrid");
  if (!grid) return;
  grid.innerHTML = popularDishes.map(dish => `
    <article class="dish-card reveal">
      <div class="dish-media">
        <img src="${dish.img}" alt="${dish.name}" loading="lazy">
        <span class="veg-badge" aria-label="Vegetarian"></span>
      </div>
      <div class="dish-body">
        <h3>${dish.name}</h3>
        <p>${dish.desc}</p>
        <div class="dish-footer">
          <span class="dish-price">${dish.price}</span>
        </div>
      </div>
    </article>
  `).join("");
}

function renderMenuItems(items){
  const grid = document.getElementById("menuGrid");
  if (!grid) return;
  grid.innerHTML = items.map(item => `
    <article class="dish-card reveal in-view" data-category="${item.category}">
      <div class="dish-media">
        <img src="${item.img}" alt="${item.name}" loading="lazy">
        <span class="veg-badge" aria-label="Vegetarian"></span>
      </div>
      <div class="dish-body">
        <h3>${item.name}</h3>
        <p>${item.desc}</p>
        <div class="dish-footer">
          <span class="dish-price">${item.price}</span>
          <button class="dish-order" data-dish="${item.name}">Order Now</button>
        </div>
      </div>
    </article>
  `).join("");

  // Wire up "Order Now" buttons to WhatsApp
  grid.querySelectorAll(".dish-order").forEach(btn => {
    btn.addEventListener("click", () => {
      const dishName = btn.getAttribute("data-dish");
      openWhatsApp(`Hi, I'd like to order: ${dishName}`);
    });
  });
}

function renderGallery(){
  const grid = document.getElementById("galleryGrid");
  if (!grid) return;
  grid.innerHTML = galleryImages.map((img, i) => `
    <div class="gallery-item reveal" data-index="${i}" role="button" tabindex="0"
         aria-label="View larger image: ${img.caption}">
      <img src="${img.src}" alt="${img.alt}" loading="lazy">
      <span class="gallery-caption">${img.caption}</span>
    </div>
  `).join("");
}

function renderReviews(){
  const grid = document.getElementById("reviewsGrid");
  if (!grid) return;
  grid.innerHTML = reviews.map(r => `
    <article class="review-card reveal">
      <span class="review-stars" aria-label="${r.rating} out of 5 stars">${starString(r.rating)}</span>
      <p class="review-text">"${r.text}"</p>
      <div class="review-author">
        <span class="review-avatar" aria-hidden="true">${r.name.charAt(0)}</span>
        <div>
          <strong>${r.name}</strong>
          <span>Google review</span>
        </div>
      </div>
    </article>
  `).join("");
}

/* =====================================================================
   INTERACTIVE FEATURES
   ===================================================================== */

/* --- WhatsApp / Call / Directions helpers -------------------------- */
function openWhatsApp(message){
  const text = encodeURIComponent(message || `Hi, I'd like to know more about ${restaurant.name}.`);
  if (restaurant.whatsapp && restaurant.whatsapp !== "ADD_WHATSAPP_NUMBER_HERE"){
    window.open(`https://wa.me/${restaurant.whatsapp}?text=${text}`, "_blank", "noopener");
  } else {
    // Fallback: no WhatsApp number configured yet — call instead.
    window.location.href = `tel:${restaurant.phone}`;
  }
}

function openDirections(){
  const query = encodeURIComponent(restaurant.address);
  window.open(`https://www.google.com/maps/dir/?api=1&destination=${query}`, "_blank", "noopener");
}

function wireActionButtons(){
  // Directions buttons (hero, location section, contact section)
  ["heroDirectionsBtn", "locationDirectionsBtn", "contactDirectionsBtn", "mabDirections"]
    .forEach(id => {
      const el = document.getElementById(id);
      if (el) el.addEventListener("click", (e) => { e.preventDefault(); openDirections(); });
    });

  // WhatsApp buttons
  ["contactWhatsappBtn", "mabWhatsapp"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener("click", (e) => { e.preventDefault(); openWhatsApp(); });
  });
}

/* --- Sticky header shadow ------------------------------------------- */
function wireStickyHeader(){
  const header = document.getElementById("siteHeader");
  if (!header) return;
  const onScroll = () => {
    header.classList.toggle("scrolled", window.scrollY > 8);
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
}

/* --- Mobile hamburger menu ------------------------------------------ */
function wireMobileNav(){
  const btn = document.getElementById("hamburgerBtn");
  const nav = document.getElementById("mainNav");
  const backdrop = document.getElementById("navBackdrop");
  if (!btn || !nav || !backdrop) return;

  function closeNav(){
    nav.classList.remove("open");
    backdrop.classList.remove("show");
    btn.classList.remove("open");
    btn.setAttribute("aria-expanded", "false");
  }
  function toggleNav(){
    const isOpen = nav.classList.toggle("open");
    backdrop.classList.toggle("show", isOpen);
    btn.classList.toggle("open", isOpen);
    btn.setAttribute("aria-expanded", String(isOpen));
  }

  btn.addEventListener("click", toggleNav);
  backdrop.addEventListener("click", closeNav);
  nav.querySelectorAll("a").forEach(link => link.addEventListener("click", closeNav));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeNav(); });
}

/* --- Menu category filtering ----------------------------------------- */
function wireMenuFilters(){
  const filterBar = document.getElementById("menuFilters");
  if (!filterBar) return;

  filterBar.addEventListener("click", (e) => {
    const btn = e.target.closest(".filter-btn");
    if (!btn) return;

    filterBar.querySelectorAll(".filter-btn").forEach(b => {
      b.classList.remove("active");
      b.setAttribute("aria-selected", "false");
    });
    btn.classList.add("active");
    btn.setAttribute("aria-selected", "true");

    const category = btn.getAttribute("data-filter");
    document.querySelectorAll("#menuGrid .dish-card").forEach(card => {
      const match = category === "all" || card.getAttribute("data-category") === category;
      card.classList.toggle("hidden", !match);
    });
  });
}

/* --- Gallery lightbox -------------------------------------------------- */
function wireLightbox(){
  const lightbox = document.getElementById("lightbox");
  const imgEl = document.getElementById("lightboxImg");
  const captionEl = document.getElementById("lightboxCaption");
  const closeBtn = document.getElementById("lightboxClose");
  const prevBtn = document.getElementById("lightboxPrev");
  const nextBtn = document.getElementById("lightboxNext");
  const grid = document.getElementById("galleryGrid");
  if (!lightbox || !grid) return;

  let currentIndex = 0;

  function show(index){
    currentIndex = (index + galleryImages.length) % galleryImages.length;
    const item = galleryImages[currentIndex];
    imgEl.src = item.src;
    imgEl.alt = item.alt;
    captionEl.textContent = item.caption;
  }

  function open(index){
    show(index);
    lightbox.hidden = false;
    document.body.style.overflow = "hidden";
    closeBtn.focus();
  }

  function close(){
    lightbox.hidden = true;
    document.body.style.overflow = "";
  }

  grid.addEventListener("click", (e) => {
    const item = e.target.closest(".gallery-item");
    if (!item) return;
    open(Number(item.getAttribute("data-index")));
  });

  grid.addEventListener("keydown", (e) => {
    if (e.key !== "Enter" && e.key !== " ") return;
    const item = e.target.closest(".gallery-item");
    if (!item) return;
    e.preventDefault();
    open(Number(item.getAttribute("data-index")));
  });

  closeBtn.addEventListener("click", close);
  prevBtn.addEventListener("click", () => show(currentIndex - 1));
  nextBtn.addEventListener("click", () => show(currentIndex + 1));

  lightbox.addEventListener("click", (e) => {
    if (e.target === lightbox) close();
  });

  document.addEventListener("keydown", (e) => {
    if (lightbox.hidden) return;
    if (e.key === "Escape") close();
    if (e.key === "ArrowLeft") show(currentIndex - 1);
    if (e.key === "ArrowRight") show(currentIndex + 1);
  });
}

/* --- "View More Reviews" (reveals the placeholder note; real
       integration point for a future Reviews API / Google widget) ---- */
function wireViewMoreReviews(){
  const btn = document.getElementById("viewMoreReviews");
  if (!btn) return;
  btn.addEventListener("click", () => {
    window.open(
      "https://www.google.com/search?q=" + encodeURIComponent(restaurant.name + " " + restaurant.address + " reviews"),
      "_blank",
      "noopener"
    );
  });
}

/* --- Scroll reveal animations ----------------------------------------- */
function wireScrollReveal(){
  const items = document.querySelectorAll(".reveal");
  if (!items.length) return;

  if (!("IntersectionObserver" in window)){
    items.forEach(el => el.classList.add("in-view"));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting){
        entry.target.classList.add("in-view");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });

  items.forEach(el => observer.observe(el));
}

/* --- Back to top button ------------------------------------------------ */
function wireBackToTop(){
  const btn = document.getElementById("backToTop");
  if (!btn) return;

  window.addEventListener("scroll", () => {
    btn.hidden = window.scrollY < 500;
    btn.classList.toggle("visible", window.scrollY >= 500);
  }, { passive: true });

  btn.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
}

/* --- Footer year -------------------------------------------------------- */
function setCurrentYear(){
  const el = document.getElementById("currentYear");
  if (el) el.textContent = new Date().getFullYear();
}

/* --- Simple legal modal (Privacy Policy / Terms placeholders) --------- */
function wireLegalModal(){
  const modal = document.getElementById("legalModal");
  const title = document.getElementById("legalModalTitle");
  const body = document.getElementById("legalModalBody");
  const closeBtn = document.getElementById("legalModalClose");
  const privacyLink = document.getElementById("privacyLink");
  const termsLink = document.getElementById("termsLink");
  if (!modal) return;

  const content = {
    privacy: {
      title: "Privacy Policy",
      body: `<p>${restaurant.name} respects your privacy. We only use the contact details you share with us
             (such as a phone call or WhatsApp message) to respond to your enquiry or order. We do not sell
             or share your information with third parties.</p>`
    },
    terms: {
      title: "Terms & Conditions",
      body: `<p>Menu items, prices and availability at ${restaurant.name} may vary day to day. Please confirm
             current prices with our staff before ordering. All food is prepared fresh and pure vegetarian.</p>`
    }
  };

  function open(key){
    title.textContent = content[key].title;
    body.innerHTML = content[key].body;
    modal.hidden = false;
    document.body.style.overflow = "hidden";
    closeBtn.focus();
  }
  function close(){
    modal.hidden = true;
    document.body.style.overflow = "";
  }

  if (privacyLink) privacyLink.addEventListener("click", (e) => { e.preventDefault(); open("privacy"); });
  if (termsLink) termsLink.addEventListener("click", (e) => { e.preventDefault(); open("terms"); });
  closeBtn.addEventListener("click", close);
  modal.addEventListener("click", (e) => { if (e.target === modal) close(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !modal.hidden) close(); });
}

/* =====================================================================
   INIT
   ===================================================================== */
document.addEventListener("DOMContentLoaded", () => {
  renderPopularDishes();
  renderMenuItems(menuItems);
  renderGallery();
  renderReviews();

  wireActionButtons();
  wireStickyHeader();
  wireMobileNav();
  wireMenuFilters();
  wireLightbox();
  wireViewMoreReviews();
  wireBackToTop();
  wireLegalModal();
  setCurrentYear();

  // Run reveal-on-scroll last, after all sections are rendered
  wireScrollReveal();
});
